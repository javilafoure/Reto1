package com.app.prototipo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "hospital")
public class Hospital {


        @Id
        public int idhospital;
        public int iddistrito;
        public String nombre;
        public int antiguedad;
        public double area;
        public int idsede;
        public int idgerente;
        public int idcondicion;
        public Date fecharegistro;

    /*public Hospital(int idhospital, int iddistrito, String nombre, int antiguedad,
                    double area, int idsede, int idgerente, int idcondicion,
                    Date fecharegistro) {

        this.idhospital = idhospital;
        this.iddistrito = iddistrito;
        this.nombre = nombre;
        this.antiguedad = antiguedad;
        this.area = area;
        this.idsede = idsede;
        this.idgerente = idgerente;
        this.idcondicion = idcondicion;
        this.fecharegistro = fecharegistro;
    }*/
}
