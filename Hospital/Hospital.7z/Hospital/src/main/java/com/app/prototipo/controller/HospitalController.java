package com.app.prototipo.controller;


import com.app.prototipo.entity.Hospital;
import com.app.prototipo.repo.HospitalRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Optional;

@Controller
public class HospitalController {
    @Autowired
    private HospitalRepo repo;

    @GetMapping("/")
    public String homePage(Model model){
        model.addAttribute("hospitalList",repo.findAll());
        return "home";
    }
    @GetMapping("/listar")
    public ResponseEntity<?> listar(){

        return ResponseEntity.ok().body(repo.findAll());
    }
    @GetMapping("/listar/{id}")
    public ResponseEntity<?> ver(@PathVariable int id){
        Optional<Hospital> o = repo.findById(id);
        if (o.isEmpty()){
            return ResponseEntity.notFound().build();
        }
        return  ResponseEntity.ok(o.get());
    }

}
